# IITH_GPT/__init__.py

# Import process_query_with_validation directly from the RAG_LLM module in Agentic_code
from .Agentic_code.RAG_LLM import process_query_with_validation
